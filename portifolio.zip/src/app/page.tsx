"use client"
const Inicio: React.FC = () => {

  return (
    <>
      <div>
        <div className="min-h-screen flex justify-center items-center">
          <h1 className="text-3xl">Bem-vindo à minha página</h1>
        </div>
      </div>

    </>
  );
};

export default Inicio;