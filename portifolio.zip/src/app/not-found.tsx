import Link from 'next/link';
import styles from './not-found.module.css';

export default function NotFound() {
  return (
    <div className={styles.container}>
      <div className={styles.textoerro}>
        <span className={styles.numero}>4</span>
        <div className={styles.pokebola}>
          <img src="/imagens/pokebola.png" alt="Pokebola" width={150} height={150} />
        </div>
        <span className={styles.numero}>4</span>
      </div>
      <p className={styles.descricaoerro}><span className={styles.oops}>Oops!</span> Não achamos esta página.</p>
      <Link href="/" legacyBehavior>
        <a className={styles.botao}>VOLTAR</a>
      </Link>
    </div>
  );
}
